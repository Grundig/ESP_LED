package com.example.esp_led

object Config{
    const val SSID="\"ESPWebServer\""
    const val PASS="\"12345678\""
}